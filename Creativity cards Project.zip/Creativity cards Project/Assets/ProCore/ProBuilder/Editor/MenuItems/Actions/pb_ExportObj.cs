using UnityEngine;
using UnityEditor;
using System.Collections;
using ProBuilder2.Common;
using ProBuilder2.EditorCommon;

namespace ProBuilder2.Actions
{
	/**
	 * Deprecated - see MenuActions/Export/ExportObj.cs
	 */
	public class pb_ExportObj : Editor
	{}
}
