#if !PROTOTYPE

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ProBuilder2.Common;
using ProBuilder2.EditorCommon;

namespace ProBuilder2.Actions
{
	/**
	 *	Moved to pb_MenuAction implementation.
	 */
	[System.Obsolete("Moved to pb_MenuAction implementation.  See SelectMaterial & SelectVertexColor")]
	public class pb_MaterialSelectionShortcut : EditorWindow {}
}

#endif
